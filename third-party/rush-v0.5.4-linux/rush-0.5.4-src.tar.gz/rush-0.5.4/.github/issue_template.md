### Prerequisites

- [ ] make sure you're are using the latest version by `rush -V`
- [ ] read the usage (rush -h) and [examples](https://github.com/shenwei356/rush#examples)

### Describe your issue

* [ ] describe the problem
* [ ] provide a reproducible example
